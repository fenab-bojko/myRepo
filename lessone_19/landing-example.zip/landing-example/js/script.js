const $buttonLogIn = document.querySelectorAll('button')

const clickLogIn

$buttonLogIn.forEach((e) => {

    e.addEventListener('click', clickLogIn)

})